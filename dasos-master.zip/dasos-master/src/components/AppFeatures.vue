<template>
    <div id="features" class="mb-6">
        <div class="bg-grey-lightest">
            <div class="container mx-auto px-6 pt-32">
                <h1 class="text-center text-black font-semibold text-2xl">
                    App Features
                </h1>
                <div class="flex md:flex-no-wrap xs:flex-wrap items-center justify-center mt-24">
                    <div class="px-6 py-6 m-2 text-center">
                        <img src="./../assets/mountain.svg" alt="mountain image" class="h-16 mb-4">
                        <h3 class="mb-4">Mountain</h3>
                        <p class="text-black font-base text-sm opacity-50">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed dignissim urna eu eros facilisis commodo. Pellentesque nec sem.
                        </p>
                    </div>
                    <div class="px-6 py-6 m-2 text-center">
                        <img src="./../assets/tent.svg" alt="tent image" class="h-16 mb-4">
                        <h3 class="mb-4">Tent</h3>
                        <p class="text-black font-base text-sm opacity-50">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed dignissim urna eu eros facilisis commodo. Pellentesque nec sem.
                        </p>
                    </div>
                    <div class="px-6 py-6 m-2 text-center">
                        <img src="./../assets/picnic.svg" alt="picnic image" class="h-16 mb-4">
                        <h3 class="mb-4">Picnic</h3>
                        <p class="text-black font-base text-sm opacity-50">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed dignissim urna eu eros facilisis commodo. Pellentesque nec sem.
                        </p>
                    </div>
                </div>
                <div class="flex md:flex-no-wrap xs:flex-wrap items-center justify-center lg:mt-64 xs:mt-0">
                    <div class="flex-1">
                        <div class="px-12 py-12 m-4 text-center">
                            <img src="./../assets/compass.svg" alt="compass image" class="h-16 mb-4">
                            <h3 class="mb-4">Compass</h3>
                            <p class="text-black font-thin text-xs opacity-50">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed dignissim urna eu eros facilisis commodo. Pellentesque nec sem.
                            </p>
                        </div>
                        <div class="px-12 py-12 m-4 text-center">
                            <img src="./../assets/canteen.svg" alt="canteen image" class="h-16 mb-4">
                            <h3 class="mb-4">Canteen</h3>
                            <p class="text-black font-thin text-xs opacity-50">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed dignissim urna eu eros facilisis commodo. Pellentesque nec sem.
                            </p>
                        </div>
                    </div>
                    <div class="xs:hidden lg:block md:flex-2 lg:flex-2">
                        <img src="./../assets/iphone.png" alt="iphone image" class="h-iphone">
                    </div>
                    <div class="flex-1">
                        <div class="px-12 py-12 m-4 text-center">
                            <img src="./../assets/forest.svg" alt="forest image" class="h-16 mb-4">
                            <h3 class="mb-4">Forest</h3>
                            <p class="text-black font-thin text-xs opacity-50">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed dignissim urna eu eros facilisis commodo. Pellentesque nec sem.
                            </p>
                        </div>
                        <div class="px-12 py-12 m-4 text-center">
                            <img src="./../assets/pines.svg" alt="pines image" class="h-16 mb-4">
                            <h3 class="mb-4">Pines</h3>
                            <p class="text-black font-thin text-xs opacity-50">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed dignissim urna eu eros facilisis commodo. Pellentesque nec sem.
                            </p>
                        </div>
    
                    </div>
                </div>
            </div>
        </div>
        <svg id="curveDownColor" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path style="fill: #f8fafc;" d="M0 0 C 50 100 80 100 100 0 Z" />
        </svg>
    </div>
</template>

<script>
    export default {
        data() {
            return {
    
            }
        }
    }
</script>
