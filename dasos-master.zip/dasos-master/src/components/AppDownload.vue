<template>
    <div id="download" class="pt-12 pb-12 w-full text-center">
        <h1 class="text-main-black font-semibold text-2xl">Download Our App</h1>
        <div class="mt-4 opacity-50 text-sm md:block xs:hidden">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </div>
        <div>
            <a href="#"> <img src="./../assets/app-store.svg" alt="" class="h-32 mr-6"></a>
            <a href="#"> <img src="./../assets/google-play.svg" alt="" class="h-32"></a>
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>