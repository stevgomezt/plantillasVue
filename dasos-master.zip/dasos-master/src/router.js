import Home  from "./Home.vue";
import Messages from "./Messages.vue";

export const routes = [
    { path: '/', component: Home },
    { path: '/messages', component: Messages }
]