import en from './en.json';

const messages = {
  en: en
};

export default messages;
