import "./assets/js/nav-pills.js";
import "./assets/scss/argon-dashboard.scss";

export default {
  install() {},
};
