<script setup>
import DefaultDashboard from "@/views/dashboards/Default.vue";
</script>
<template>
  <default-dashboard />
</template>
