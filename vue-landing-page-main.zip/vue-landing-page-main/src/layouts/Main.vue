<script setup>
import HeroSection from "../sections/HeroSection.vue";
import FeatureSection from "../sections/FeatureSection.vue";
import DownloadSection from "../sections/DownloadSection.vue";
import FaqSection from "../sections/FaqSection.vue";
import SubscribeSection from "../sections/SubscribeSection.vue";
</script>

<template>
    <HeroSection />

    <FeatureSection />

    <DownloadSection />

    <FaqSection />

    <SubscribeSection />
</template>
