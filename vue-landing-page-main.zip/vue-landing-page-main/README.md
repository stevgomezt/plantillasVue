# Landing page made with Tailwind css and Vue js.

> ### Live URL: https://fahimanzamdip.github.io/vue-landing-page/

## Local Installation
- `` git clone https://github.com/FahimAnzamDip/vue-landing-page.git ``
- `` cd /path/to/project ``
- `` npm install ``
- `` npm run dev ``

## Screenshot
![vue-landing-page](screenshot.png)
