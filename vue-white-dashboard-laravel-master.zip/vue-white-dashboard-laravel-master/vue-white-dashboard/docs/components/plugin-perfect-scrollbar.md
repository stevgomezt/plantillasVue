# Plugin perfect scrollbar

“Minimalistic but perfect custom scrollbar plugin.”


!IMPORTANT Perfect Scrollbar is applied on the `Sidebar` component so we will have a nice scrollbar
that is visible only when you actually scroll.
Since it is changing the overflows of the CSS it is also affecting 
the child elements which have a scroll so please make sure that you add the  
class .ps-child to any element that should have scroll.

For more information please check [Full Github Documentation](https://github.com/utatti/perfect-scrollbar)
