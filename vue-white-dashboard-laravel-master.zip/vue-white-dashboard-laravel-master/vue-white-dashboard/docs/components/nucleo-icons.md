# Nucleo Icons


<p>Through most of the examples in this kit, we have used 100 Nucleo Icons for the Black Dashboard. View all the
<a href="https://demos.creative-tim.com/vue-black-dashboard/#/icons">example icons</a>. If you want more than 2100 icons please check the official
<a href="https://nucleoapp.com/?ref=1712">Nucleo Icons Pack</a>.</p>

:::demo
```html
<i class="tim-icons icon-single-02"></i>
```
:::
