# Changelog

## [1.1.0] 2022-01-11

- Update dependencies and devDependencies
- Migrate from `node-sass` to `sass`
- Fix issue when running `npm i`

## [1.0.0] 2020-10-01

### Stable Original Release
