declare module 'vue3-apexcharts';
