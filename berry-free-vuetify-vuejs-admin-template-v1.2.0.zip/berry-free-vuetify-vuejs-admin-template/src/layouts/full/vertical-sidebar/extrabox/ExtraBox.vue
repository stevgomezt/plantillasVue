<script setup lang="ts"></script>

<template>
  <div class="bg-lightwarning rounded-md pa-5 my-3 circle sm-circle lg-circle hide-menu">
    <h4>Upgrade To Pro</h4>
    <h6 class="text-subtitle-2 text-medium-emphasis pr-11 mb-3 mt-2">To get more features and components</h6>
    <v-btn color="warning" variant="flat" target="_" href="https://codedthemes.com/item/berry-vue-admin-dashboard/"> Go Premium </v-btn>
  </div>
</template>
