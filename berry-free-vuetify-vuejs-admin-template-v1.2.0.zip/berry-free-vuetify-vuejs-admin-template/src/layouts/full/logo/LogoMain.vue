<script setup>
import LogoDark from './LogoDark.vue';
</script>
<template>
  <LogoDark />
</template>
